document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById('sensorChart').getContext('2d');
        var sensorChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Temperatura (°C)',
                        data: [],
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        fill: true
                    },
                    {
                        label: 'Umidade (%)',
                        data: [],
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'hour'
                        },
                        title: {
                            display: true,
                            text: 'Timestamp'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Valor'
                        },
                        min: -30, // Defina o valor mínimo para o eixo Y
                        max: 100 // Defina o valor máximo para o eixo Y, ajuste conforme necessário
                    }
                }
            }
        });

        // Função para carregar os dados via AJAX
        $.ajax({
            url: '/api/sensor_data',
            type: 'GET',
            success: function(data) {
                const labels = data.map(item => new Date(item.timestamp));
                const temperaturas = data.map(item => item.temperatura);
                const umidades = data.map(item => item.umidade);

                sensorChart.data.labels = labels;
                sensorChart.data.datasets[0].data = temperaturas;
                sensorChart.data.datasets[1].data = umidades;
                sensorChart.update();
            },
            error: function(error) {
                console.error("Erro ao buscar os dados:", error);
            }
        })})